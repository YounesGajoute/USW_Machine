MASTER DATABASE INITIALIZER DEPENDENCY SUPPLEMENT - 2026-10-27

Extract the original master-source-profile-2-20261027.tar.gz into an isolated test
directory, then extract this supplement into that SAME directory. Preserve paths.
Never extract this supplement over a real station checkout or configuration: it
contains a synthetic backend/config/default-users.json at the real lookup path.
No production seed/configuration was copied, read or modified to create this fixture.

Unmodified Master source files added:
  backend/lib/crypto.mjs
  backend/lib/legacyRoleNames.mjs
  backend/lib/defaultUsers.mjs

Dependency closure for the real db.mjs initializer:
  db.mjs -> crypto.mjs -> node:crypto
  db.mjs -> legacyRoleNames.mjs (no imports)
  db.mjs -> defaultUsers.mjs -> legacyRoleNames.mjs
  defaultUsers.mjs -> node:fs, node:path, node:url
  defaultUsers.mjs reads backend/config/default-users.json
  db.mjs also uses node:fs, node:path, node:url and better-sqlite3
There are no additional local modules or seed resources for this initializer.
better-sqlite3 is the existing external dependency declared in backend/package.json;
use an installed Node-compatible build. node_modules is not included in the archive.

Synthetic data (not a snapshot of the station configuration):
  backend/config/default-users.json
Five explicit fixture identities cover the five canonical account roles. All are
inactive, with public test-only passwords and test ID numbers. defaultUsers.mjs
parses this normally; no code is substituted and its built-in fallback is not used.
The unmodified helper still contains its upstream fallback literals; those are not
evidence of the station's configured credentials. Never use this fixture in deployment.

Additional verification test (archive-only, not production code):
  backend/lib/visionSync/seed-handoff.test.mjs
This checks that the real initializer creates exactly the synthetic inactive users,
hashes their passwords and preserves that behavior when an isolated database reopens.

Run from the extracted backend directory:
  node --test lib/visionSync/database.test.mjs lib/visionSync/seed-handoff.test.mjs

This test command uses fresh temporary databases. It does not load index.mjs, connect
to a station or exercise hardware. Do not call openDatabase(getDbPath()) for these
checks: supply an explicit isolated path, as the tests do. The original database
test uses the actual revision store, not a replacement SQL schema.

Scope: this supplement closes db.mjs's local dependency graph only. It is not a full
application distribution and does not claim index.mjs or all commissioning-control
tests have every application dependency. Do not run npm start or deploy either archive.
Production synchronization remains disabled; profile revision 2 acceptance is still
the Slave agent's verification decision.
