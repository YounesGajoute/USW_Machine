#pragma once
#include <stdint.h>
#define PROGMEM
#define PSTR(value) (value)
using PGM_P = const char*;
inline uint8_t pgm_read_byte(const uint8_t* p) { return *p; }
